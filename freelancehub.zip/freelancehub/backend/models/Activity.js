const mongoose = require('mongoose');

// Login Log Schema
const loginLogSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  loginTime: {
    type: Date,
    default: Date.now
  },
  logoutTime: {
    type: Date,
    default: null
  },
  sessionStatus: {
    type: String,
    enum: ['active', 'expired', 'manual_logout'],
    default: 'active'
  },
  ipAddress: {
    type: String,
    default: 'Unknown'
  },
  deviceInfo: {
    type: String,
    default: 'Unknown'
  },
  tokenId: {
    type: String,
    required: true
  }
}, { timestamps: true });

loginLogSchema.index({ userId: 1, loginTime: -1 });

// Like Schema
const likeSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  postId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Post',
    required: true
  }
}, { timestamps: true });

likeSchema.index({ userId: 1, postId: 1 }, { unique: true });

// Comment Schema
const commentSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  postId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Post',
    required: true
  },
  comment: {
    type: String,
    required: [true, 'Comment cannot be empty'],
    trim: true,
    maxlength: [500, 'Comment cannot exceed 500 characters']
  },
  isDeleted: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

commentSchema.index({ postId: 1, createdAt: -1 });

// Blocked User Schema
const blockedUserSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  blockedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  blockedReason: {
    type: String,
    default: 'Violation of platform terms'
  },
  blockedAt: {
    type: Date,
    default: Date.now
  }
}, { timestamps: true });

module.exports = {
  LoginLog: mongoose.model('LoginLog', loginLogSchema),
  Like: mongoose.model('Like', likeSchema),
  Comment: mongoose.model('Comment', commentSchema),
  BlockedUser: mongoose.model('BlockedUser', blockedUserSchema)
};
