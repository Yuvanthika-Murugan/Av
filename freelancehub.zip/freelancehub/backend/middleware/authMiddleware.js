const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { LoginLog } = require('../models/Activity');

// Verify JWT token and session validity
const protect = async (req, res, next) => {
  try {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ success: false, message: 'Not authorized. No token provided.' });
    }

    // Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        // Mark session as expired
        if (decoded && decoded.tokenId) {
          await LoginLog.findOneAndUpdate(
            { tokenId: decoded.tokenId, sessionStatus: 'active' },
            { logoutTime: new Date(), sessionStatus: 'expired' }
          );
        }
        return res.status(401).json({ success: false, message: 'Session expired. Please login again.', code: 'TOKEN_EXPIRED' });
      }
      return res.status(401).json({ success: false, message: 'Invalid token.' });
    }

    // Check if user exists
    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }

    // Check if user is blocked
    if (user.isBlocked) {
      return res.status(403).json({ success: false, message: 'Your account has been blocked. Contact support.', code: 'ACCOUNT_BLOCKED' });
    }

    // Verify session is still active in DB
    const activeSession = await LoginLog.findOne({
      tokenId: decoded.tokenId,
      sessionStatus: 'active'
    });

    if (!activeSession) {
      return res.status(401).json({ success: false, message: 'Session is no longer active. Please login again.', code: 'SESSION_INVALID' });
    }

    req.user = user;
    req.tokenId = decoded.tokenId;
    next();
  } catch (err) {
    console.error('Auth middleware error:', err);
    res.status(500).json({ success: false, message: 'Authentication error.' });
  }
};

// Admin only access
const adminOnly = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access required.' });
  }
  next();
};

// Optional auth (doesn't fail if no token)
const optionalAuth = async (req, res, next) => {
  try {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id);
    }
  } catch (err) {
    // Silent fail for optional auth
  }
  next();
};

module.exports = { protect, adminOnly, optionalAuth };
