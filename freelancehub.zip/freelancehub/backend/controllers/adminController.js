const User = require('../models/User');
const Post = require('../models/Post');
const { LoginLog, BlockedUser, Comment } = require('../models/Activity');

// GET /api/admin/dashboard
const getDashboard = async (req, res) => {
  try {
    const [
      totalUsers, totalPosts, pendingPosts, blockedUsers,
      activeSessions, recentPosts, recentUsers
    ] = await Promise.all([
      User.countDocuments({ role: 'user' }),
      Post.countDocuments({ isDeleted: false }),
      Post.countDocuments({ approvalStatus: 'pending', isDeleted: false }),
      User.countDocuments({ isBlocked: true }),
      LoginLog.countDocuments({ sessionStatus: 'active' }),
      Post.find({ isDeleted: false }).populate('userId', 'name profileImage').sort({ createdAt: -1 }).limit(5),
      User.find({ role: 'user' }).sort({ createdAt: -1 }).limit(5)
    ]);

    // Stats for chart (last 7 days)
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const dailyStats = await LoginLog.aggregate([
      { $match: { loginTime: { $gte: sevenDaysAgo } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$loginTime' } }, logins: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      success: true,
      stats: { totalUsers, totalPosts, pendingPosts, blockedUsers, activeSessions },
      recentPosts, recentUsers, dailyStats
    });
  } catch (err) {
    console.error('Admin dashboard error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard data.' });
  }
};

// GET /api/admin/posts
const getAllPosts = async (req, res) => {
  try {
    const { page = 1, limit = 15, status, search, category } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const query = { isDeleted: false };
    if (status) query.approvalStatus = status;
    if (category) query.category = category;
    if (search) query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } }
    ];

    const [posts, total] = await Promise.all([
      Post.find(query).populate('userId', 'name email profileImage').sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      Post.countDocuments(query)
    ]);

    res.json({
      success: true, posts,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)), totalPosts: total }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch posts.' });
  }
};

// PUT /api/admin/posts/:id/approve
const approvePost = async (req, res) => {
  try {
    const post = await Post.findByIdAndUpdate(
      req.params.id,
      { approvalStatus: 'approved', approvedBy: req.user._id, approvedAt: new Date(), rejectionReason: null },
      { new: true }
    ).populate('userId', 'name email');

    if (!post) return res.status(404).json({ success: false, message: 'Post not found.' });
    res.json({ success: true, message: 'Post approved and published.', post });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to approve post.' });
  }
};

// PUT /api/admin/posts/:id/reject
const rejectPost = async (req, res) => {
  try {
    const { reason } = req.body;
    const post = await Post.findByIdAndUpdate(
      req.params.id,
      { approvalStatus: 'rejected', rejectionReason: reason || 'Does not meet platform standards', approvedBy: req.user._id, approvedAt: new Date() },
      { new: true }
    ).populate('userId', 'name email');

    if (!post) return res.status(404).json({ success: false, message: 'Post not found.' });
    res.json({ success: true, message: 'Post rejected.', post });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to reject post.' });
  }
};

// PUT /api/admin/posts/:id/delete
const adminDeletePost = async (req, res) => {
  try {
    await Post.findByIdAndUpdate(req.params.id, { isDeleted: true });
    res.json({ success: true, message: 'Post permanently removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete post.' });
  }
};

// GET /api/admin/users
const getAllUsers = async (req, res) => {
  try {
    const { page = 1, limit = 15, search, status } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const query = { role: 'user' };
    if (status === 'blocked') query.isBlocked = true;
    if (status === 'active') query.isBlocked = false;
    if (search) query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } }
    ];

    const [users, total] = await Promise.all([
      User.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      User.countDocuments(query)
    ]);

    // Enrich with post counts
    const enriched = await Promise.all(users.map(async u => {
      const postCount = await Post.countDocuments({ userId: u._id, isDeleted: false });
      const lastLogin = await LoginLog.findOne({ userId: u._id }).sort({ loginTime: -1 });
      return { ...u.toObject(), postCount, lastLogin: lastLogin?.loginTime };
    }));

    res.json({
      success: true, users: enriched,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)), totalUsers: total }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch users.' });
  }
};

// PUT /api/admin/users/:id/block
const blockUser = async (req, res) => {
  try {
    const { reason } = req.body;
    const user = await User.findByIdAndUpdate(req.params.id, { isBlocked: true }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    await BlockedUser.findOneAndUpdate(
      { userId: user._id },
      { userId: user._id, blockedBy: req.user._id, blockedReason: reason || 'Policy violation', blockedAt: new Date() },
      { upsert: true, new: true }
    );

    // Expire all active sessions
    await LoginLog.updateMany({ userId: user._id, sessionStatus: 'active' }, { logoutTime: new Date(), sessionStatus: 'expired' });

    res.json({ success: true, message: `User ${user.name} has been blocked.`, user });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to block user.' });
  }
};

// PUT /api/admin/users/:id/unblock
const unblockUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isBlocked: false }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    await BlockedUser.deleteOne({ userId: user._id });
    res.json({ success: true, message: `User ${user.name} has been unblocked.`, user });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to unblock user.' });
  }
};

// DELETE /api/admin/comments/:id
const deleteComment = async (req, res) => {
  try {
    const comment = await Comment.findByIdAndUpdate(req.params.id, { isDeleted: true }, { new: true });
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });
    await Post.findByIdAndUpdate(comment.postId, { $inc: { commentsCount: -1 } });
    res.json({ success: true, message: 'Comment removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete comment.' });
  }
};

module.exports = { getDashboard, getAllPosts, approvePost, rejectPost, adminDeletePost, getAllUsers, blockUser, unblockUser, deleteComment };
