const Post = require('../models/Post');
const { Like, Comment } = require('../models/Activity');

// GET /api/posts (public feed - approved only, infinite scroll)
const getFeed = async (req, res) => {
  try {
    const { page = 1, limit = 10, category, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const query = { approvalStatus: 'approved', isDeleted: false };
    if (category && category !== 'All') query.category = category;
    if (search) query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
      { skills: { $in: [new RegExp(search, 'i')] } }
    ];

    const [posts, total] = await Promise.all([
      Post.find(query)
        .populate('userId', 'name profileImage isOnline')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit)),
      Post.countDocuments(query)
    ]);

    // Add user's like status if authenticated
    let likedPostIds = new Set();
    if (req.user) {
      const likes = await Like.find({ userId: req.user._id, postId: { $in: posts.map(p => p._id) } });
      likedPostIds = new Set(likes.map(l => l.postId.toString()));
    }

    const postsWithLikes = posts.map(p => ({
      ...p.toObject(),
      isLiked: likedPostIds.has(p._id.toString())
    }));

    res.json({
      success: true,
      posts: postsWithLikes,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        totalPosts: total,
        hasNextPage: skip + posts.length < total
      }
    });
  } catch (err) {
    console.error('Get feed error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch posts.' });
  }
};

// POST /api/posts (create)
const createPost = async (req, res) => {
  try {
    const { title, description, category, skills, budget } = req.body;
    const skillsArray = Array.isArray(skills) ? skills : skills.split(',').map(s => s.trim()).filter(Boolean);

    const post = await Post.create({
      userId: req.user._id,
      title, description, category, budget,
      skills: skillsArray,
      image: req.file ? req.file.path : null,
      imagePublicId: req.file ? req.file.filename : null
    });

    await post.populate('userId', 'name profileImage');
    res.status(201).json({ success: true, message: 'Post submitted for approval.', post });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(e => e.message);
      return res.status(400).json({ success: false, message: messages[0] });
    }
    console.error('Create post error:', err);
    res.status(500).json({ success: false, message: 'Failed to create post.' });
  }
};

// GET /api/posts/my-posts
const getMyPosts = async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const query = { userId: req.user._id, isDeleted: false };
    if (status) query.approvalStatus = status;

    const [posts, total] = await Promise.all([
      Post.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      Post.countDocuments(query)
    ]);

    res.json({
      success: true, posts,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)), totalPosts: total }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch your posts.' });
  }
};

// GET /api/posts/:id
const getPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('userId', 'name profileImage bio skills isOnline');
    if (!post || post.isDeleted) {
      return res.status(404).json({ success: false, message: 'Post not found.' });
    }

    const comments = await Comment.find({ postId: post._id, isDeleted: false })
      .populate('userId', 'name profileImage')
      .sort({ createdAt: -1 })
      .limit(20);

    let isLiked = false;
    if (req.user) {
      const like = await Like.findOne({ userId: req.user._id, postId: post._id });
      isLiked = !!like;
    }

    res.json({ success: true, post: { ...post.toObject(), isLiked }, comments });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch post.' });
  }
};

// PUT /api/posts/:id
const updatePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post || post.isDeleted) return res.status(404).json({ success: false, message: 'Post not found.' });
    if (post.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }

    const { title, description, category, skills, budget } = req.body;
    const updates = { title, description, category, budget, approvalStatus: 'pending' };
    if (skills) updates.skills = Array.isArray(skills) ? skills : skills.split(',').map(s => s.trim());
    if (req.file) { updates.image = req.file.path; updates.imagePublicId = req.file.filename; }

    const updated = await Post.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    res.json({ success: true, message: 'Post updated and re-submitted for approval.', post: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update post.' });
  }
};

// DELETE /api/posts/:id
const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post || post.isDeleted) return res.status(404).json({ success: false, message: 'Post not found.' });

    const isOwner = post.userId.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';
    if (!isOwner && !isAdmin) return res.status(403).json({ success: false, message: 'Not authorized.' });

    await Post.findByIdAndUpdate(req.params.id, { isDeleted: true });
    res.json({ success: true, message: 'Post deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete post.' });
  }
};

// POST /api/posts/:id/like
const toggleLike = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post || post.approvalStatus !== 'approved') {
      return res.status(404).json({ success: false, message: 'Post not found.' });
    }

    const existing = await Like.findOne({ userId: req.user._id, postId: post._id });
    let liked;

    if (existing) {
      await Like.deleteOne({ _id: existing._id });
      await Post.findByIdAndUpdate(post._id, { $inc: { likesCount: -1 } });
      liked = false;
    } else {
      await Like.create({ userId: req.user._id, postId: post._id });
      await Post.findByIdAndUpdate(post._id, { $inc: { likesCount: 1 } });
      liked = true;
    }

    const updated = await Post.findById(post._id);
    res.json({ success: true, liked, likesCount: updated.likesCount });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to toggle like.' });
  }
};

// POST /api/posts/:id/comment
const addComment = async (req, res) => {
  try {
    const { comment } = req.body;
    if (!comment || !comment.trim()) {
      return res.status(400).json({ success: false, message: 'Comment cannot be empty.' });
    }

    const post = await Post.findById(req.params.id);
    if (!post || post.approvalStatus !== 'approved') {
      return res.status(404).json({ success: false, message: 'Post not found.' });
    }

    const newComment = await Comment.create({ userId: req.user._id, postId: post._id, comment: comment.trim() });
    await Post.findByIdAndUpdate(post._id, { $inc: { commentsCount: 1 } });
    await newComment.populate('userId', 'name profileImage');

    res.status(201).json({ success: true, comment: newComment });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to add comment.' });
  }
};

// GET /api/posts/:id/comments
const getComments = async (req, res) => {
  try {
    const comments = await Comment.find({ postId: req.params.id, isDeleted: false })
      .populate('userId', 'name profileImage')
      .sort({ createdAt: -1 })
      .limit(50);
    res.json({ success: true, comments });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch comments.' });
  }
};

module.exports = { getFeed, createPost, getMyPosts, getPost, updatePost, deletePost, toggleLike, addComment, getComments };
