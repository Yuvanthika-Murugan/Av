const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const User = require('../models/User');
const { LoginLog } = require('../models/Activity');

const generateToken = (userId, tokenId) => {
  return jwt.sign(
    { id: userId, tokenId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '5h' }
  );
};

const getClientInfo = (req) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || 'Unknown';
  const ua = req.headers['user-agent'] || 'Unknown';
  return { ip: ip.split(',')[0].trim(), ua };
};

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const { name, email, mobile, password } = req.body;

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Email already registered.' });
    }

    const user = await User.create({ name, email, mobile, password });

    res.status(201).json({
      success: true,
      message: 'Account created successfully. Please login.',
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(e => e.message);
      return res.status(400).json({ success: false, message: messages[0] });
    }
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Registration failed.' });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { ip, ua } = getClientInfo(req);

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    if (user.isBlocked) {
      return res.status(403).json({ success: false, message: 'Your account has been blocked. Contact support.' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    const tokenId = uuidv4();
    const token = generateToken(user._id, tokenId);

    // Mark any old active sessions as expired
    await LoginLog.updateMany(
      { userId: user._id, sessionStatus: 'active' },
      { logoutTime: new Date(), sessionStatus: 'expired' }
    );

    // Create login log
    await LoginLog.create({
      userId: user._id,
      loginTime: new Date(),
      sessionStatus: 'active',
      ipAddress: ip,
      deviceInfo: ua.substring(0, 200),
      tokenId
    });

    // Update user online status
    await User.findByIdAndUpdate(user._id, { isOnline: true, lastSeen: new Date() });

    res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        mobile: user.mobile,
        role: user.role,
        profileImage: user.profileImage,
        bio: user.bio,
        skills: user.skills
      },
      sessionExpiresIn: 5 * 60 * 60 * 1000 // 5 hours in ms
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Login failed.' });
  }
};

// POST /api/auth/logout
const logout = async (req, res) => {
  try {
    await LoginLog.findOneAndUpdate(
      { tokenId: req.tokenId, sessionStatus: 'active' },
      { logoutTime: new Date(), sessionStatus: 'manual_logout' }
    );

    await User.findByIdAndUpdate(req.user._id, { isOnline: false, lastSeen: new Date() });

    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (err) {
    console.error('Logout error:', err);
    res.status(500).json({ success: false, message: 'Logout failed.' });
  }
};

// GET /api/auth/me
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch profile.' });
  }
};

// PUT /api/auth/update-profile
const updateProfile = async (req, res) => {
  try {
    const { name, mobile, bio, skills } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (mobile) updates.mobile = mobile;
    if (bio !== undefined) updates.bio = bio;
    if (skills) updates.skills = Array.isArray(skills) ? skills : skills.split(',').map(s => s.trim());

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
    res.json({ success: true, message: 'Profile updated.', user });
  } catch (err) {
    console.error('Update profile error:', err);
    res.status(500).json({ success: false, message: 'Profile update failed.' });
  }
};

// PUT /api/auth/change-password
const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id).select('+password');

    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Current password is incorrect.' });
    }

    user.password = newPassword;
    await user.save();

    res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Password change failed.' });
  }
};

module.exports = { register, login, logout, getMe, updateProfile, changePassword };
