const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { LoginLog } = require('../models/Activity');

// GET /api/logs - Admin: all logs
router.get('/', protect, adminOnly, async (req, res) => {
  try {
    const { page = 1, limit = 20, userId, status } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const query = {};
    if (userId) query.userId = userId;
    if (status) query.sessionStatus = status;

    const [logs, total] = await Promise.all([
      LoginLog.find(query)
        .populate('userId', 'name email')
        .sort({ loginTime: -1 })
        .skip(skip)
        .limit(parseInt(limit)),
      LoginLog.countDocuments(query)
    ]);

    res.json({
      success: true, logs,
      pagination: { currentPage: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)), total }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch logs.' });
  }
});

// GET /api/logs/my-sessions - User's own sessions
router.get('/my-sessions', protect, async (req, res) => {
  try {
    const logs = await LoginLog.find({ userId: req.user._id }).sort({ loginTime: -1 }).limit(10);
    res.json({ success: true, logs });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch sessions.' });
  }
});

module.exports = router;
