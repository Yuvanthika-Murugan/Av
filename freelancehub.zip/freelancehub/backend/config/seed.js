const User = require('../models/User');

const seedAdmin = async () => {
  try {
    const existing = await User.findOne({ email: process.env.ADMIN_EMAIL });
    if (!existing) {
      await User.create({
        name: 'Admin',
        email: process.env.ADMIN_EMAIL || 'admin@freelancehub.com',
        mobile: '+1 000 000 0000',
        password: process.env.ADMIN_PASSWORD || 'Admin@123456',
        role: 'admin'
      });
      console.log('✅ Admin user seeded:', process.env.ADMIN_EMAIL);
    }
  } catch (err) {
    console.error('Seed admin error:', err.message);
  }
};

module.exports = { seedAdmin };
